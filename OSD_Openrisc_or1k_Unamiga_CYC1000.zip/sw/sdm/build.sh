#!/bin/sh
gcc -Wall sdm.c -o sdm && ./sdm

